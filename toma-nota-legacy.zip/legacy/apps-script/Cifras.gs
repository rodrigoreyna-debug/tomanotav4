/**
 * TomaNota – Cifras diarias del panel (referencia para la nueva versión)
 *
 * Cada noche (23:45, hora del centro de México) agrega una fila a una hoja de Google con:
 *   - Esperaban respuesta: leads que nos escribieron por WhatsApp ese día.
 *   - Contactados el mismo día: de ellos, a cuántos les escribimos después de su primer mensaje, ese mismo día.
 *   - Más de 24 h sin contacto: leads que al cierre llevan más de 24 h esperando respuesta.
 *
 * Instalación: crear este archivo en el mismo proyecto de Apps Script (Archivos → + → Script),
 * pegar el código, guardar y ejecutar instalarCifras() una vez.
 */

const CIFRAS_TZ = 'America/Mexico_City';
const CIFRAS_SHEET_NAME = 'TomaNota – Cifras diarias del panel';

/** Ejecutar UNA vez: crea la hoja, programa el registro diario y registra el día de hoy. */
function instalarCifras() {
  ScriptApp.getProjectTriggers().forEach(t => {
    if (t.getHandlerFunction() === 'registrarCifras') ScriptApp.deleteTrigger(t);
  });
  ScriptApp.newTrigger('registrarCifras').timeBased().everyDays(1).atHour(23).nearMinute(45).inTimezone(CIFRAS_TZ).create();
  const ss = hojaCifras_();
  console.log('Hoja: ' + ss.getUrl());
  registrarCifras();
}

/** Registra las cifras del día de hoy (lo llama el disparador cada noche). */
function registrarCifras() {
  try { actualizarDatos(); } catch (e) { console.log('Sin actualizar datos: ' + e.message); }
  registrarDia_(new Date());
}

/** Registra un día anterior, por ejemplo registrarFecha('2026-11-09'). Útil si un día falló. */
function registrarFecha(iso) {
  registrarDia_(new Date(iso + 'T12:00:00-06:00'));
}

function registrarDia_(fecha) {
  const d = JSON.parse(readCache_());
  const dia = Utilities.formatDate(fecha, CIFRAS_TZ, 'yyyy-MM-dd');
  const t0 = Math.floor(new Date(dia + 'T00:00:00-06:00').getTime() / 1000);
  const t1 = t0 + 86400;
  const corte = Math.min(t1, d.generatedAt);

  const lead = {};
  for (const r of d.leads) lead[r[0]] = r;

  let esperaban = 0, contactados = 0, mas24 = 0;
  for (const c of d.conv) {
    const r = lead[c[0]];
    if (!r) continue;
    const ins = c[5] || [], outs = c[6] || [];
    const wa = r[8] || 0, cerrada = r[9] || 0;
    if (wa) continue; // con nota "Seguimiento por WhatsApp": fuera de las alertas, igual que en el panel
    // ¿Nos escribió ese día? Se toma su primer mensaje del día
    const pendiente = ins.filter(t => t >= t0 && t < t1).sort((a, b) => a - b)[0] || 0;
    if (pendiente) {
      esperaban++;
      if (outs.some(o => o > pendiente && o < t1)) contactados++;
    }
    // Al cierre: último mensaje es suyo, tiene más de 24 h, y no está fuera de alertas (nota WhatsApp / conversación cerrada)
    const li = Math.max(0, ...ins.filter(t => t < corte)), lo = Math.max(0, ...outs.filter(t => t < corte));
    if (li > lo && corte - li > 86400 && !wa && !(cerrada && cerrada >= li)) mas24++;
  }

  const sh = hojaCifras_().getSheets()[0];
  const fila = [dia, esperaban, contactados, esperaban ? contactados / esperaban : '', mas24,
    Utilities.formatDate(new Date(d.generatedAt * 1000), CIFRAS_TZ, 'yyyy-MM-dd HH:mm')];
  const datos = sh.getDataRange().getValues();
  const idx = datos.findIndex((x, i) => i > 0 && Utilities.formatDate(new Date(x[0]), CIFRAS_TZ, 'yyyy-MM-dd') === dia);
  if (idx > 0) sh.getRange(idx + 1, 1, 1, fila.length).setValues([fila]);
  else sh.appendRow(fila);
  sh.getRange(2, 4, sh.getLastRow(), 1).setNumberFormat('0%');
  console.log('Cifras ' + dia + ': esperaban ' + esperaban + ', contactados el mismo día ' + contactados + ', más de 24 h sin contacto ' + mas24);
}

function hojaCifras_() {
  const props = PropertiesService.getScriptProperties();
  const id = props.getProperty('CIFRAS_SHEET_ID');
  if (id) { try { return SpreadsheetApp.openById(id); } catch (e) { /* se creó otra vez abajo */ } }
  const ss = SpreadsheetApp.create(CIFRAS_SHEET_NAME);
  const sh = ss.getSheets()[0];
  sh.setName('Cifras');
  sh.appendRow(['Fecha', 'Esperaban respuesta', 'Contactados el mismo día', '% contactados', 'Más de 24 h sin contacto (al cierre)', 'Datos del panel de']);
  sh.setFrozenRows(1);
  sh.getRange(1, 1, 1, 6).setFontWeight('bold');
  props.setProperty('CIFRAS_SHEET_ID', ss.getId());
  return ss;
}

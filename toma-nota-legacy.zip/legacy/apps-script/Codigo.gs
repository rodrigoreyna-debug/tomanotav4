/**
 * TomaNota – Panel Kommo (datos) · versión Google Apps Script
 *
 * Reemplaza el flujo de n8n:
 *   - actualizarDatos(): lee Kommo, calcula y guarda el resultado (disparador cada 15 min).
 *   - doGet(): entrega los datos al panel de Netlify (?key=CLAVE).
 *
 * Propiedades del script (Configuración del proyecto → Propiedades del script):
 *   KOMMO_TOKEN  token de larga duración de Kommo
 *   PANEL_KEY    clave que se escribe en el panel
 */

const SUBDOMAIN = 'tomanotamx';
const BASE = 'https://' + SUBDOMAIN + '.kommo.com/api/v4/';
// Embudos excluidos: Bolsa de Trabajo/Proveedores, Familia TN, Agente Test, Agente Test QRO, QRO Álamos, QRO Refugio, LEÓN
const EXCL = [13226643, 13226647, 13601944, 14015624, 13226627, 13226631, 13359635];
const DAYS = 180;          // ventana de cambios de etapa
const CHAT_DAYS = 30;      // ventana de mensajes de WhatsApp
const THRESH = 3 * 3600;   // 3 h sin respuesta
const CF_CITA = 1276880;   // campo "Próxima cita"
const EDAD_RX = /edad/i;    // respaldo: campo cuyo nombre contenga "edad"
// Campos personalizados (del contacto o del lead)
const CF_CITA_FH = 1372607;  // Fecha y hora de cita
const CF_SUCURSAL = 1003576; // Sucursal
const CF_EDAD = 1377765;     // Edad del niño
const MAX_MS = 5 * 60 * 1000; // margen bajo el límite de 6 min de Apps Script
const FILE_NAME = 'tomanota_panel_cache.json';

/* ---------------- Web app ---------------- */

function doGet(e) {
  const props = PropertiesService.getScriptProperties();
  const key = (e && e.parameter && e.parameter.key) || '';
  if (!key || key !== props.getProperty('PANEL_KEY')) return json_({ error: 'unauthorized' });
  const s = readCache_();
  if (!s) return json_({ error: 'sin_datos' });
  // Se agregan las marcas de asistencia guardadas desde el panel (Llegó / No llegó)
  const out = s.slice(0, s.lastIndexOf('}')) + ',"asistencia":' + JSON.stringify(readAsis_()) + '}';
  return ContentService.createTextOutput(out).setMimeType(ContentService.MimeType.JSON);
}

/**
 * Recibe acciones desde el panel (cuerpo en texto JSON):
 *   {key, lead, r: 'si' | 'no' | '' (deshacer), by}  → guarda la marca de asistencia.
 *        Con 'si' además crea en Kommo la nota "Lead asistió a cita".
 *   {key, lead, action: 'nota', text, by}            → crea en Kommo una nota con ese texto.
 */
function doPost(e) {
  const props = PropertiesService.getScriptProperties();
  let b = {};
  try { b = JSON.parse((e && e.postData && e.postData.contents) || '{}'); } catch (err) { return json_({ error: 'formato' }); }
  if (!b.key || b.key !== props.getProperty('PANEL_KEY')) return json_({ error: 'unauthorized' });
  const lead = parseInt(b.lead, 10);
  if (!lead) return json_({ error: 'lead' });
  if (b.action === 'nota') {
    const text = String(b.text || '').trim().slice(0, 2000);
    if (!text) return json_({ error: 'nota_vacia' });
    const err = addNote_(lead, text, b.by);
    if (err) return json_({ error: err });
    // Se registra que el lead ya tiene nota de seguimiento (para sacarlo de "Citas pasadas")
    const lock = LockService.getScriptLock();
    lock.waitLock(10000);
    try {
      const a = readAsis_();
      a[lead] = Object.assign(a[lead] || {}, { nota: Math.floor(Date.now() / 1000), notaBy: String(b.by || '').slice(0, 60) });
      writeAsis_(a);
      return json_({ ok: true, asistencia: a });
    } finally {
      lock.releaseLock();
    }
  }
  const lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    const a = readAsis_();
    if (b.r === 'si' || b.r === 'no') a[lead] = Object.assign(a[lead] || {}, { r: b.r, t: Math.floor(Date.now() / 1000), by: String(b.by || '').slice(0, 60) });
    else if (a[lead]) { delete a[lead].r; delete a[lead].t; delete a[lead].by; if (!a[lead].nota) delete a[lead]; }
    writeAsis_(a);
    const noteErr = b.r === 'si' ? addNote_(lead, 'Lead asistió a cita', b.by) : null;
    return json_({ ok: true, asistencia: a, noteError: noteErr });
  } finally {
    lock.releaseLock();
  }
}

/** Crea una nota común en el lead de Kommo. Devuelve null si salió bien o el texto del error. */
function addNote_(lead, text, by) {
  const firma = by ? ' (' + String(by).slice(0, 60) + ', desde el panel de seguimiento)' : ' (desde el panel de seguimiento)';
  const r = UrlFetchApp.fetch(BASE + 'leads/notes', {
    method: 'post', contentType: 'application/json', headers: headers_(), muteHttpExceptions: true,
    payload: JSON.stringify([{ entity_id: lead, note_type: 'common', params: { text: text + firma } }])
  });
  const c = r.getResponseCode();
  return c === 200 || c === 201 ? null : 'Kommo respondió HTTP ' + c + ' ' + r.getContentText().slice(0, 150);
}

function readAsis_() {
  const id = PropertiesService.getScriptProperties().getProperty('ASIS_FILE_ID');
  if (!id) return {};
  try { return JSON.parse(DriveApp.getFileById(id).getBlob().getDataAsString() || '{}'); } catch (e) { return {}; }
}

function writeAsis_(a) {
  // Se conservan solo las marcas de los últimos 120 días
  const lim = Math.floor(Date.now() / 1000) - 120 * 86400;
  for (const k of Object.keys(a)) if (!a[k] || Math.max(a[k].t || 0, a[k].nota || 0) < lim) delete a[k];
  const props = PropertiesService.getScriptProperties();
  const s = JSON.stringify(a);
  const id = props.getProperty('ASIS_FILE_ID');
  let file = null;
  if (id) { try { file = DriveApp.getFileById(id); } catch (e) { file = null; } }
  if (file) file.setContent(s);
  else { file = DriveApp.createFile('tomanota_asistencia_citas.json', s, MimeType.PLAIN_TEXT); props.setProperty('ASIS_FILE_ID', file.getId()); }
}

function json_(o) {
  return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);
}

/* ---------------- Instalación ---------------- */

/** Ejecutar UNA vez: crea el disparador cada 15 minutos y hace la primera carga. */
function instalar() {
  ScriptApp.getProjectTriggers().forEach(t => {
    if (t.getHandlerFunction() === 'actualizarDatos') ScriptApp.deleteTrigger(t);
  });
  ScriptApp.newTrigger('actualizarDatos').timeBased().everyMinutes(15).create();
  actualizarDatos();
}

/* ---------------- Kommo ---------------- */

function headers_() {
  const token = PropertiesService.getScriptProperties().getProperty('KOMMO_TOKEN');
  if (!token) throw new Error('Falta la propiedad KOMMO_TOKEN');
  return { Authorization: 'Bearer ' + token };
}

function getOne_(path) {
  const r = UrlFetchApp.fetch(BASE + path, { headers: headers_(), muteHttpExceptions: true });
  if (r.getResponseCode() !== 200) throw new Error(path + ' → HTTP ' + r.getResponseCode() + ' ' + r.getContentText().slice(0, 200));
  return JSON.parse(r.getContentText());
}

/**
 * Descarga todas las páginas de un listado (4 en paralelo, respetando ~7 peticiones/s de Kommo).
 * optional=true: si el endpoint falla, devuelve [] en lugar de detener todo.
 */
function getPaged_(path, listKey, t0, optional) {
  const sep = path.indexOf('?') >= 0 ? '&' : '?';
  const h = headers_();
  const out = [];
  let page = 1, done = false;
  while (!done) {
    if (Date.now() - t0 > MAX_MS) throw new Error('Tiempo agotado leyendo ' + path.split('?')[0]);
    const start = Date.now();
    const reqs = [];
    for (let i = 0; i < 4; i++) reqs.push({ url: BASE + path + sep + 'page=' + (page + i), headers: h, muteHttpExceptions: true });
    const res = fetchBatch_(reqs);
    for (const r of res) {
      const code = r.getResponseCode();
      if (code === 204) { done = true; break; }
      if (code !== 200) {
        if (optional) return out;
        throw new Error(path.split('?')[0] + ' → HTTP ' + code + ' ' + r.getContentText().slice(0, 200));
      }
      const b = JSON.parse(r.getContentText());
      const items = (b._embedded && b._embedded[listKey]) || [];
      for (const it of items) out.push(it);
      // /talks no trae _links.next: ahí se sigue mientras la página venga llena
      const more = listKey === 'talks' ? items.length >= 250 : !!(b._links && b._links.next);
      if (!items.length || !more) { done = true; break; }
    }
    page += 4;
    const wait = 1000 - (Date.now() - start);
    if (!done && wait > 0) Utilities.sleep(wait);
  }
  return out;
}

/** fetchAll con reintentos: si Google o Kommo cortan la conexión, reintenta una por una. */
function fetchBatch_(reqs) {
  try {
    const res = UrlFetchApp.fetchAll(reqs);
    if (!res.some(r => r.getResponseCode() === 429 || r.getResponseCode() >= 500)) return res;
  } catch (e) { /* "Dirección no disponible" u otro corte: reintentar abajo */ }
  return reqs.map(fetchRetry_);
}

function fetchRetry_(req) {
  let lastErr;
  for (let i = 0; i < 4; i++) {
    Utilities.sleep(1500 * (i + 1));
    try {
      const r = UrlFetchApp.fetch(req.url, { headers: req.headers, muteHttpExceptions: true });
      const c = r.getResponseCode();
      if (c !== 429 && c < 500) return r;
      lastErr = new Error('HTTP ' + c);
    } catch (e) { lastErr = e; }
  }
  throw new Error('Kommo no respondió tras varios intentos: ' + req.url.split('?')[0] + ' (' + lastErr.message + ')');
}

/* ---------------- Ingreso en enero ---------------- */

const ENERO_RX = /ener+o/i;

/**
 * Leads en "En evaluación" con alguna nota (del lead o de su contacto) que mencione enero.
 * Guarda en la posición 11 de la fila: [fecha de la nota, extracto].
 */
function markEnero_(leadsAll, active, activeMap, pipelines, notesRaw, t0) {
  const evalSt = new Set();
  for (const p of pipelines) for (const s of p.statuses) if (/en evaluaci[oó]n/i.test(s.name)) evalSt.add(p.id + ':' + s.id);
  const target = {};
  for (const row of active) if (evalSt.has(row[2] + ':' + row[3])) target[row[0]] = row;
  const best = {};
  const take = (lid, n) => {
    const txt = String((n.params && n.params.text) || '');
    if (!ENERO_RX.test(txt)) return;
    const t = n.created_at || 0;
    if (!best[lid] || t > best[lid][0]) best[lid] = [t, txt.replace(/\s+/g, ' ').slice(0, 160)];
  };
  // Notas del lead (ya descargadas)
  for (const n of notesRaw) if (target[n.entity_id]) take(n.entity_id, n);
  // Notas del contacto principal
  const leadsOfContact = {};
  for (const l of leadsAll) {
    if (!target[l.id]) continue;
    const cs = (l._embedded && l._embedded.contacts) || [];
    const main = cs.find(c => c.is_main) || cs[0];
    if (main) (leadsOfContact[main.id] = leadsOfContact[main.id] || []).push(l.id);
  }
  const cids = Object.keys(leadsOfContact);
  const h = headers_();
  for (let i = 0; i < cids.length; i += 200) {
    if (Date.now() - t0 > MAX_MS - 45000) break;
    const reqs = [];
    for (let j = i; j < Math.min(i + 200, cids.length); j += 50) {
      reqs.push({ url: BASE + 'contacts/notes?limit=250&filter[note_type]=common&' + cids.slice(j, j + 50).map(x => 'filter[entity_id][]=' + x).join('&'), headers: h, muteHttpExceptions: true });
    }
    for (const r of fetchBatch_(reqs)) {
      if (r.getResponseCode() !== 200) continue;
      const b = JSON.parse(r.getContentText());
      for (const n of ((b._embedded && b._embedded.notes) || [])) for (const lid of (leadsOfContact[n.entity_id] || [])) take(lid, n);
    }
    Utilities.sleep(800);
  }
  for (const lid of Object.keys(best)) target[lid][11] = best[lid];
}

/* ---------------- Campos de cita (contacto o lead) ---------------- */

function toTs_(v) {
  if (v == null || v === '') return null;
  if (typeof v === 'number') return v;
  if (/^\d+$/.test(String(v))) return parseInt(v, 10);
  const t = Math.floor(Date.parse(v) / 1000);
  return isNaN(t) ? null : t;
}

/** Lee fecha de cita, sucursal y edad de una lista de custom_fields_values. */
function citaFields_(cfv) {
  const out = {};
  for (const f of (cfv || [])) {
    const vals = (f.values || []).map(v => v.value).filter(v => v !== null && v !== '');
    if (!vals.length) continue;
    if (f.field_id === CF_CITA_FH) out.cita = toTs_(vals[0]);
    else if (f.field_id === CF_SUCURSAL) out.sucursal = String(vals.join(', ')).slice(0, 60);
    else if (f.field_id === CF_EDAD) out.edad = String(vals.join(', ')).slice(0, 40);
  }
  return out;
}

/* ---------------- Duplicados ---------------- */

/** Agrega a cada fila activa (posición 10) la lista de IDs de los otros leads activos que comparten contacto o teléfono. */
function markDuplicates_(leadsAll, active, activeMap, t0) {
  const contactOf = {};
  for (const l of leadsAll) {
    if (!activeMap[l.id]) continue;
    const cs = (l._embedded && l._embedded.contacts) || [];
    const main = cs.find(c => c.is_main) || cs[0];
    if (main) contactOf[l.id] = main.id;
  }
  // Teléfonos de esos contactos (en lotes de 50)
  const ids = Array.from(new Set(Object.values(contactOf)));
  const phonesOf = {}, cfOf = {};
  const h = headers_();
  for (let i = 0; i < ids.length; i += 200) {
    if (Date.now() - t0 > MAX_MS - 30000) break;
    const reqs = [];
    for (let j = i; j < Math.min(i + 200, ids.length); j += 50) {
      reqs.push({ url: BASE + 'contacts?limit=250&' + ids.slice(j, j + 50).map(x => 'filter[id][]=' + x).join('&'), headers: h, muteHttpExceptions: true });
    }
    for (const r of fetchBatch_(reqs)) {
      if (r.getResponseCode() !== 200) continue;
      const b = JSON.parse(r.getContentText());
      for (const c of ((b._embedded && b._embedded.contacts) || [])) {
        const ph = [];
        for (const f of (c.custom_fields_values || [])) {
          if (f.field_code !== 'PHONE') continue;
          for (const v of (f.values || [])) { const d = String(v.value || '').replace(/\D/g, '').slice(-10); if (d.length === 10) ph.push(d); }
        }
        phonesOf[c.id] = ph;
        cfOf[c.id] = citaFields_(c.custom_fields_values);
      }
    }
    Utilities.sleep(800);
  }
  // Agrupar por contacto y por teléfono
  const groups = {};
  const add = (k, id) => (groups[k] = groups[k] || new Set()).add(id);
  for (const lid of Object.keys(contactOf)) {
    const cid = contactOf[lid];
    add('c' + cid, +lid);
    for (const ph of (phonesOf[cid] || [])) add('p' + ph, +lid);
  }
  const dup = {};
  for (const k of Object.keys(groups)) {
    const g = Array.from(groups[k]);
    if (g.length < 2 || g.length > 6) continue; // grupos enormes suelen ser teléfonos genéricos
    for (const a of g) { dup[a] = dup[a] || new Set(); for (const b of g) if (b !== a) dup[a].add(b); }
  }
  for (const row of active) {
    row[10] = dup[row[0]] ? Array.from(dup[row[0]]) : 0;
    // Datos de cita del contacto principal (si el lead no los tiene)
    const cf = cfOf[contactOf[row[0]]];
    if (cf) {
      if (cf.cita && !row[13]) row[13] = cf.cita;
      if (cf.sucursal && !row[14]) row[14] = cf.sucursal;
      if (cf.edad && !row[12]) row[12] = cf.edad;
    }
  }
}

/* ---------------- Eventos incrementales ---------------- */

/**
 * Mantiene en Drive los eventos de Kommo de la ventana indicada.
 * Primera vez: descarga por partes (retoma en la siguiente corrida si se acaba el tiempo).
 * Después: solo pide los eventos de la última hora y media hacia adelante.
 */
function syncEvents_(name, typeFilter, fromTs, now, t0, compact) {
  const props = PropertiesService.getScriptProperties();
  const key = 'EV_' + name;
  let state = null;
  try { const id = props.getProperty(key); if (id) state = JSON.parse(DriveApp.getFileById(id).getBlob().getDataAsString()); } catch (e) { state = null; }
  if (!state || !state.recs) state = { recs: [], maxT: 0, back: { from: fromTs, page: 1 } };

  const seen = new Set(state.recs.map(r => r[0]));
  const add = arr => { for (const e of arr) { if (seen.has(e.id)) continue; const r = compact(e); seen.add(e.id); if (r) { state.recs.push(r); if (r[2] > state.maxT) state.maxT = r[2]; } } };

  const deadline = t0 + MAX_MS - 20000;
  if (state.back) {
    const res = getPagedUntil_('events?limit=100&' + typeFilter + '&filter[created_at][from]=' + state.back.from, 'events', state.back.page, deadline);
    add(res.items);
    state.back = res.nextPage ? { from: state.back.from, page: res.nextPage } : null;
  } else {
    const since = Math.max(fromTs, state.maxT - 5400);
    const res = getPagedUntil_('events?limit=100&' + typeFilter + '&filter[created_at][from]=' + since, 'events', 1, deadline);
    add(res.items);
    if (res.nextPage) state.back = { from: since, page: res.nextPage };
  }
  state.recs = state.recs.filter(r => r[2] >= fromTs);

  const s = JSON.stringify(state);
  let file = null;
  const id = props.getProperty(key);
  if (id) { try { file = DriveApp.getFileById(id); } catch (e) { file = null; } }
  if (file) file.setContent(s);
  else { file = DriveApp.createFile('tomanota_eventos_' + name + '.json', s, MimeType.PLAIN_TEXT); props.setProperty(key, file.getId()); }
  return { recs: state.recs, complete: !state.back };
}

/** Como getPaged_, pero se detiene antes del límite de tiempo y dice en qué página siguió. */
function getPagedUntil_(path, listKey, startPage, deadline) {
  const h = headers_();
  const items = [];
  let page = startPage;
  while (true) {
    if (Date.now() > deadline) return { items, nextPage: page };
    const start = Date.now();
    const reqs = [];
    for (let i = 0; i < 4; i++) reqs.push({ url: BASE + path + '&page=' + (page + i), headers: h, muteHttpExceptions: true });
    const res = fetchBatch_(reqs);
    for (const r of res) {
      const code = r.getResponseCode();
      if (code === 204) return { items, nextPage: null };
      if (code !== 200) throw new Error(path.split('?')[0] + ' → HTTP ' + code + ' ' + r.getContentText().slice(0, 200));
      const b = JSON.parse(r.getContentText());
      const arr = (b._embedded && b._embedded[listKey]) || [];
      for (const it of arr) items.push(it);
      if (!arr.length || !(b._links && b._links.next)) return { items, nextPage: null };
    }
    page += 4;
    const wait = 1000 - (Date.now() - start);
    if (wait > 0) Utilities.sleep(wait);
  }
}

/* ---------------- Cálculo ---------------- */

function actualizarDatos() {
  const lock = LockService.getScriptLock();
  if (!lock.tryLock(1000)) return; // ya hay una actualización en curso
  try {
    const t0 = Date.now();
    const now = Math.floor(t0 / 1000);
    const winStart = now - DAYS * 86400;

    const pipesRaw = getOne_('leads/pipelines')._embedded.pipelines;
    const pipelines = pipesRaw.filter(p => EXCL.indexOf(p.id) < 0).map(p => ({
      id: p.id, name: p.name, sort: p.sort,
      statuses: p._embedded.statuses.map(s => ({ id: s.id, name: s.name, sort: s.sort, color: s.color }))
    }));
    const incl = new Set(pipelines.map(p => p.id));

    const users = getOne_('users?limit=250')._embedded.users.map(u => ({ id: u.id, name: u.name, active: !!(u.rights && u.rights.is_active) }));

    const pipeFilter = pipelines.map(p => 'filter[pipeline_id][]=' + p.id).join('&');
    const leadsAll = getPaged_('leads?limit=250&with=contacts&' + pipeFilter, 'leads', t0);
    const talksRaw = getPaged_('talks?limit=250', 'talks', t0, true);
    const notesRaw = getPaged_('leads/notes?limit=250&filter[note_type]=common&filter[updated_at][from]=' + winStart, 'notes', t0, true);

    // Eventos: se guardan en Drive y cada vez solo se piden los nuevos (la primera carga puede tomar varias corridas)
    const st = syncEvents_('st', 'filter[type]=lead_status_changed', winStart, now, t0, e => {
      if (e.entity_type !== 'lead') return null;
      const b = e.value_before && e.value_before[0] && e.value_before[0].lead_status;
      const a = e.value_after && e.value_after[0] && e.value_after[0].lead_status;
      return [e.id, e.entity_id, e.created_at, b ? b.pipeline_id : 0, b ? b.id : 0, a ? a.pipeline_id : 0, a ? a.id : 0];
    });
    const ch = syncEvents_('ch', 'filter[type][]=incoming_chat_message&filter[type][]=outgoing_chat_message', now - CHAT_DAYS * 86400, now, t0, e => {
      const m = e.value_after && e.value_after[0] && e.value_after[0].message;
      if (e.entity_type !== 'lead' || !m || m.origin !== 'waba') return null;
      return [e.id, e.entity_id, e.created_at, e.type === 'incoming_chat_message' ? 1 : 0];
    });
    if (!st.complete || !ch.complete) {
      console.log('Carga inicial de eventos en curso (cambios de etapa: ' + st.recs.length + ', mensajes: ' + ch.recs.length + '). Continúa en la siguiente corrida.');
      return;
    }
    const ls = (p, s) => p ? [{ lead_status: { pipeline_id: p, id: s } }] : [];
    const stEv = st.recs.map(r => ({ entity_type: 'lead', entity_id: r[1], created_at: r[2], value_before: ls(r[3], r[4]), value_after: ls(r[5], r[6]) }));
    const chRaw = ch.recs.map(r => ({ entity_type: 'lead', entity_id: r[1], created_at: r[2], type: r[3] ? 'incoming_chat_message' : 'outgoing_chat_message', value_after: [{ message: { origin: 'waba' } }] }));

    const leadMap = {};
    for (const l of leadsAll) leadMap[l.id] = l;

    // Cambios de etapa
    stEv.sort((a, b) => a.created_at - b.created_at);
    const byLead = {};
    for (const e of stEv) (byLead[e.entity_id] = byLead[e.entity_id] || []).push(e);
    const transitions = [];
    const enteredAt = {};
    for (const lid of Object.keys(byLead)) {
      const lead = leadMap[lid];
      let prevTime = lead && lead.created_at >= winStart ? lead.created_at : null;
      for (const e of byLead[lid]) {
        const b = e.value_before && e.value_before[0] && e.value_before[0].lead_status;
        const a = e.value_after && e.value_after[0] && e.value_after[0].lead_status;
        if (!a) continue;
        if (b && prevTime !== null && incl.has(b.pipeline_id) && incl.has(a.pipeline_id)) {
          transitions.push([b.pipeline_id, b.id, a.pipeline_id, a.id, lead ? lead.responsible_user_id : 0,
            Math.round((e.created_at - prevTime) / 36) / 100, e.created_at]);
        }
        prevTime = e.created_at;
        enteredAt[lid] = { t: e.created_at, s: a.id, p: a.pipeline_id };
      }
    }

    // Notas "Seguimiento por WhatsApp"
    const WA_RX = /segui\w*\s*(?:por\s*)?(?:el\s*)?whats?\s*app/i;
    const waNote = {};
    for (const n of notesRaw) {
      const txt = (n.params && n.params.text) || '';
      if (n.entity_id && WA_RX.test(txt)) waNote[n.entity_id] = Math.max(waNote[n.entity_id] || 0, n.created_at || 0);
    }
    // Última conversación por lead (¿cerrada?)
    const lastTalk = {};
    for (const tk of talksRaw) {
      if (tk.entity_type !== 'lead' || !tk.entity_id) continue;
      const cur = lastTalk[tk.entity_id];
      if (!cur || tk.talk_id > cur.id) lastTalk[tk.entity_id] = { id: tk.talk_id, open: !!tk.is_in_work, at: tk.updated_at };
    }

    // Leads activos
    const active = [];
    const activeMap = {};
    for (const l of leadsAll) {
      if (!incl.has(l.pipeline_id) || l.status_id === 142 || l.status_id === 143 || l.is_deleted) continue;
      const en = enteredAt[l.id];
      let since = null;
      if (en && en.s === l.status_id && en.p === l.pipeline_id) since = en.t;
      else if (l.created_at >= winStart) since = l.created_at;
      let cita = null, edad = '';
      for (const f of (l.custom_fields_values || [])) {
        if (!edad && EDAD_RX.test(f.field_name || '') && f.values && f.values[0]) edad = String(f.values.map(v => v.value).join(', ')).slice(0, 40);
        if (f.field_id === CF_CITA && f.values && f.values[0]) {
          const v = f.values[0].value;
          cita = typeof v === 'number' ? v : (/^\d+$/.test(String(v)) ? parseInt(v, 10) : Math.floor(Date.parse(v) / 1000) || null);
        }
      }
      const lt = lastTalk[l.id];
      const row = [l.id, l.name || ('Lead #' + l.id), l.pipeline_id, l.status_id, l.responsible_user_id, l.created_at, since, cita, waNote[l.id] || 0, lt && !lt.open ? lt.at : 0];
      active.push(row);
      const lf = citaFields_(l.custom_fields_values);
      row[12] = lf.edad || edad;
      row[13] = lf.cita || null;      // fecha y hora de cita (campo 1372607)
      row[14] = lf.sucursal || '';    // sucursal (campo 1003576)
      activeMap[l.id] = row;
    }

    // Ingreso en enero y posibles duplicados
    try { markEnero_(leadsAll, active, activeMap, pipelines, notesRaw, t0); } catch (e) { console.log('Notas de enero no calculadas: ' + e.message); }
    try { markDuplicates_(leadsAll, active, activeMap, t0); } catch (e) { console.log('Duplicados no calculados: ' + e.message); }

    // Conversaciones de WhatsApp
    const chEv = chRaw.filter(e => e.entity_type === 'lead' && e.value_after && e.value_after[0] && e.value_after[0].message && e.value_after[0].message.origin === 'waba');
    const last = {};
    for (const e of chEv) {
      const r = (last[e.entity_id] = last[e.entity_id] || { i: 0, o: 0 });
      if (e.type === 'incoming_chat_message') r.i = Math.max(r.i, e.created_at);
      else r.o = Math.max(r.o, e.created_at);
    }
    const chats = [];
    for (const lid of Object.keys(last)) {
      if (!activeMap[lid]) continue;
      const r = last[lid];
      if (r.i > r.o && now - r.i > THRESH) chats.push([+lid, 'n', r.i, r.i, r.o]);
      else if (r.o > r.i && now - r.o > THRESH) chats.push([+lid, 'c', r.o, r.i, r.o]);
    }

    // Envíos masivos: minutos con mensajes salientes a 15+ leads distintos (no cuentan como intento)
    const minuteLeads = {};
    for (const e of chEv) if (e.type !== 'incoming_chat_message') {
      const m = Math.floor(e.created_at / 60);
      (minuteLeads[m] = minuteLeads[m] || new Set()).add(e.entity_id);
    }
    const massMin = new Set(Object.keys(minuteLeads).filter(m => minuteLeads[m].size >= 15).map(Number));
    const evByLead = {};
    for (const e of chEv) {
      const inc = e.type === 'incoming_chat_message' ? 1 : 0;
      if (!inc && massMin.has(Math.floor(e.created_at / 60))) continue;
      (evByLead[e.entity_id] = evByLead[e.entity_id] || []).push([e.created_at, inc]);
    }
    const conv = [];
    for (const lid of Object.keys(evByLead)) {
      if (!activeMap[lid]) continue;
      const ev = evByLead[lid].sort((a, b) => a[0] - b[0]);
      let li = 0, lo = 0;
      for (const x of ev) { if (x[1]) li = x[0]; else lo = x[0]; }
      const outsAfter = ev.filter(x => !x[1] && x[0] > li).map(x => x[0]);
      conv.push([+lid, li, lo, outsAfter.length, outsAfter[0] || 0, ev.filter(x => x[1]).map(x => x[0]), ev.filter(x => !x[1]).map(x => x[0])]);
    }

    const tgMap = {};
    for (const t of transitions) {
      const k = t.slice(0, 5).join('|');
      (tgMap[k] = tgMap[k] || [t[0], t[1], t[2], t[3], t[4], []])[5].push(t[5] < 10 ? Math.round(t[5] * 10) / 10 : Math.round(t[5]));
    }

    const result = {
      generatedAt: now, windowDays: DAYS, chatWindowDays: CHAT_DAYS, thresholdHours: 3,
      subdomain: SUBDOMAIN,
      pipelines, users, leads: active, transitions: Object.values(tgMap), chats, conv,
      massMinutes: massMin.size,
      stats: {
        waLeads: Object.keys(waNote).length, talks: Object.keys(lastTalk).length, notes: notesRaw.length,
        leadsFetched: leadsAll.length, statusEvents: stEv.length, chatEvents: chEv.length,
        enero: active.filter(r => Array.isArray(r[11])).length,
        seconds: Math.round((Date.now() - t0) / 1000)
      }
    };
    writeCache_(JSON.stringify(result));
    console.log('OK', JSON.stringify(result.stats));
  } finally {
    lock.releaseLock();
  }
}

/* ---------------- Almacenamiento (archivo en Drive + caché rápida) ---------------- */

function writeCache_(s) {
  const props = PropertiesService.getScriptProperties();
  let file = null;
  const id = props.getProperty('CACHE_FILE_ID');
  if (id) { try { file = DriveApp.getFileById(id); } catch (e) { file = null; } }
  if (file) file.setContent(s);
  else { file = DriveApp.createFile(FILE_NAME, s, MimeType.PLAIN_TEXT); props.setProperty('CACHE_FILE_ID', file.getId()); }

  // Copia rápida en CacheService (trozos de 90 KB, 6 h)
  const cache = CacheService.getScriptCache();
  const SIZE = 90000, n = Math.ceil(s.length / SIZE), map = { tn_n: String(n) };
  for (let i = 0; i < n; i++) map['tn_' + i] = s.slice(i * SIZE, (i + 1) * SIZE);
  try { cache.putAll(map, 21600); } catch (e) { cache.remove('tn_n'); }
}

function readCache_() {
  const cache = CacheService.getScriptCache();
  const n = parseInt(cache.get('tn_n') || '0', 10);
  if (n) {
    const keys = [];
    for (let i = 0; i < n; i++) keys.push('tn_' + i);
    const got = cache.getAll(keys);
    if (keys.every(k => got[k] != null)) return keys.map(k => got[k]).join('');
  }
  const id = PropertiesService.getScriptProperties().getProperty('CACHE_FILE_ID');
  if (!id) return null;
  try { return DriveApp.getFileById(id).getBlob().getDataAsString(); } catch (e) { return null; }
}

/* ---------------- Diagnóstico ---------------- */

/** Muestra en el registro los embudos, etapas, usuarios y campos personalizados de la cuenta. */
function diagnostico() {
  const p = getOne_('leads/pipelines')._embedded.pipelines;
  p.forEach(x => console.log('EMBUDO ' + x.id + ' | ' + x.name + '\n' + x._embedded.statuses.map(s => '   ' + s.id + ' | ' + s.name).join('\n')));
  getOne_('users?limit=250')._embedded.users.forEach(u => console.log('USUARIO ' + u.id + ' | ' + u.name));
  const f = getOne_('leads/custom_fields?limit=250');
  ((f._embedded && f._embedded.custom_fields) || []).forEach(c => console.log('CAMPO ' + c.id + ' | ' + c.name + ' | ' + c.type));
}

/** Actualiza los datos y escribe en el registro los leads en evaluación con nota de enero. */
function listarEnero() {
  actualizarDatos();
  const d = JSON.parse(readCache_());
  const pn = {}, st = {};
  d.pipelines.forEach(p => { pn[p.id] = p.name; p.statuses.forEach(s => st[p.id + ':' + s.id] = s.name); });
  const rows = d.leads.filter(r => Array.isArray(r[11]));
  console.log('Leads en evaluación con nota de enero: ' + rows.length);
  rows.sort((a, b) => b[11][0] - a[11][0]).forEach(r => console.log(
    r[1] + ' | ' + pn[r[2]] + ' · ' + st[r[2] + ':' + r[3]] +
    ' | ' + new Date(r[11][0] * 1000).toLocaleDateString('es-MX') + ': ' + r[11][1] +
    ' | https://' + SUBDOMAIN + '.kommo.com/leads/detail/' + r[0]));
}

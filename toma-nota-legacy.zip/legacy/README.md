# Panel actual de Toma Nota (legacy)

Versión en producción hasta el cambio a la nueva app. No contiene credenciales: el token de Kommo y la clave del panel viven solo en las Propiedades del script de Apps Script.

## Piezas

| Carpeta | Qué es | Dónde corre |
|---|---|---|
| `apps-script/Codigo.gs` | Lee Kommo cada 15 min (disparador), calcula y guarda en Drive. `doGet` entrega los datos al panel con `?key=`; `doPost` guarda asistencia a cita y crea notas en Kommo. | Google Apps Script, proyecto «TomaNota Panel» |
| `apps-script/Cifras.gs` | Registro diario (23:45 CDMX) de cifras de referencia en la hoja «TomaNota – Cifras diarias del panel». | Mismo proyecto de Apps Script |
| `netlify/` | Página publicada (`/` = Pendientes, Citas de hoy, Citas pasadas, Resumen dirección; `/tablero` = etapas y tiempos). | Netlify, sitio tomanotav4 |
| `fuentes/` | `pendientes.html` (fuente del panel) y `build_netlify.py` (genera `netlify/index.html`). | — |

## Propiedades del script (no se suben aquí)

- `KOMMO_TOKEN`: token de larga duración de la integración privada (vence 1 ene 2028).
- `PANEL_KEY`: clave común del panel.
- `CACHE_FILE_ID`, `EV_st`, `EV_ch`, `ASIS_FILE_ID`, `CIFRAS_SHEET_ID`: los crea el script.

## Escrituras en Kommo

El panel crea notas en el lead (no mueve etapas ni borra):
- «Lead asistió a cita» al marcar *Sí llegó a cita*.
- Notas de seguimiento escritas en *Citas pasadas* / *Citas de hoy*.

## Campos de Kommo que usa

- Fecha y hora de cita `1372607`, Sucursal `1003576`, Edad del niño `1377765` (lead o contacto principal).
- Próxima cita `1276880` (respaldo).

## Regenerar la página

```
python3 fuentes/build_netlify.py fuentes/pendientes.html netlify/index.html "https://script.google.com/macros/s/<ID>/exec"
```

"""
Convierte pendientes.html (prototipo de Claude, lee n8n por MCP) en la página de Netlify,
que lee los datos del script de Google Apps Script con una clave.

Uso: python3 build_netlify.py pendientes.html salida/index.html "https://script.google.com/macros/s/.../exec"
"""
import re
import sys

src, dst = sys.argv[1], sys.argv[2]
API_URL = sys.argv[3] if len(sys.argv) > 3 else ""
if not API_URL:
    sys.exit("Falta la URL /exec del script de Apps Script")
s = open(src, encoding="utf-8").read()

# 1. Carga de datos: fetch al script en lugar del conector MCP
i = s.index('async function load(refresh){')
j = s.index('/* ---------- clasificación ---------- */')
newload = '''const API = "''' + API_URL + '''";
const getKey = () => store("tn_key") || "";
function setKey(k){ try { k ? localStorage.setItem("tn_key", k) : localStorage.removeItem("tn_key"); } catch(e){} }
function loginBusy(on, txt){ const b = $("loginBtn"); if (!b) return; b.disabled = on; b.textContent = on ? (txt || "Cargando datos…") : "Entrar"; }
function loginMsg(m){ if (!$("login").hidden) $("loginMsg").textContent = m; }
function askKey(msg){ $("login").hidden = false; loginBusy(false); $("loginMsg").textContent = msg || ""; $("keyInput").focus(); }
window.addEventListener("error", e => { loginBusy(false); loginMsg("Error al mostrar el panel: " + e.message); setStatus("Error al mostrar el panel: " + esc(e.message), "warn"); });
async function postAsis(lead, r, by){
  const res = await fetch(API, { method: "POST", headers: { "Content-Type": "text/plain;charset=utf-8" }, body: JSON.stringify({ key: getKey(), lead, r, by }) });
  if (!res.ok) throw new Error("HTTP " + res.status);
  const j = await res.json();
  if (j.error) throw new Error(j.error === "unauthorized" ? "clave no válida" : j.error);
  return j;
}
async function postNota(lead, text, by){
  const res = await fetch(API, { method: "POST", headers: { "Content-Type": "text/plain;charset=utf-8" }, body: JSON.stringify({ key: getKey(), action: "nota", lead, text, by }) });
  if (!res.ok) throw new Error("HTTP " + res.status);
  const j = await res.json();
  if (j.error) throw new Error(j.error === "unauthorized" ? "clave no válida" : j.error);
  return j;
}
async function load(){
  const key = getKey();
  if (!key){ askKey(""); return; }
  setStatus("Cargando pendientes desde Kommo…");
  loginBusy(true);
  try{
    const r = await fetch(API + "?key=" + encodeURIComponent(key), { cache: "no-store" });
    if (!r.ok) throw new Error("HTTP " + r.status);
    const j = await r.json();
    if (j.error === "unauthorized"){ setKey(""); setStatus(""); askKey("La clave no es correcta. Revisa y vuelve a intentar."); return; }
    if (j.error){ loginBusy(false); loginMsg(j.error === "sin_datos" ? "Todavía no hay datos calculados." : "Respuesta inesperada del servidor: " + j.error); }
    if (j.error === "sin_datos"){ setStatus("Todavía no hay datos calculados. Se generan cada 15 minutos.", "warn"); return; }
    if (j.error) return;
    D = j; setStatus(""); prepare(); render();
    $("login").hidden = true; loginBusy(false);
  }catch(e){
    loginBusy(false);
    loginMsg("No se pudo cargar: " + e.message);
    setStatus("No se pudo cargar (" + esc(e.message) + "). Pulsa Actualizar en un momento.", "warn");
  }
}

'''
s = s[:i] + newload + s[j:]

# 2. Botones Actualizar / Salir, refresco cada 10 min
assert 'load(false);' in s
s = s.replace('load(false);', '''$("reload").addEventListener("click", load);
$("loginForm").addEventListener("submit", e => { e.preventDefault(); const k = $("keyInput").value.trim(); if (!k) return; setKey(k); $("keyInput").value = ""; load(); });
$("logout").addEventListener("click", () => { setKey(""); location.reload(); });
setInterval(() => { if (getKey() && !document.hidden) load(); }, 10 * 60 * 1000);
load();''')
anchor = '<div class="branch"><label for="fUser">'
assert anchor in s
s = s.replace(anchor, '<div class="hbtns"><button class="btn sm" id="reload">Actualizar</button><button class="btn sm" id="logout" title="Olvidar la clave en este navegador">Salir</button></div>\n    ' + anchor, 1)

# 3. Pantalla de clave (con el logo del panel)
m = re.search(r'<img class="logo"[^>]*>', s)
logo = m.group(0).replace('class="logo"', 'class="logo" style="height:80px;margin:0 auto"') if m else '<div class="logo">TOMA NOTA</div>'
login = '''
<div id="login" class="login" hidden>
  <form id="loginForm" class="login-card">
    ''' + logo + '''
    <div class="sub">Pendientes de hoy</div>
    <label for="keyInput">Clave de acceso</label>
    <input id="keyInput" type="password" autocomplete="current-password" required>
    <p id="loginMsg" class="login-msg"></p>
    <button class="btn primary" type="submit" id="loginBtn">Entrar</button>
    <p class="explain">La clave se guarda en este navegador. Pídesela a tu coordinador si no la tienes.</p>
  </form>
</div>
'''
s = s.replace('\n<script>', login + '\n<script>', 1)

css = '''[hidden]{display:none!important}
.hbtns{display:flex;gap:6px;align-self:flex-end}
.btn.sm{min-height:36px;padding:6px 12px;font-size:13px}
.login{position:fixed;inset:0;background:var(--bg);display:flex;align-items:center;justify-content:center;padding:16px;z-index:30}
.login-card{background:var(--card);border:1px solid var(--line);border-radius:var(--radius);padding:24px;width:100%;max-width:380px;display:grid;gap:10px}
.login-card label{font-size:11px;text-transform:uppercase;letter-spacing:.09em;color:var(--faint);font-weight:700;margin-top:8px}
.login-card input{height:44px;border:1px solid var(--line);border-radius:10px;padding:0 12px;font:inherit;background:var(--bg);color:var(--ink)}
.login-msg{margin:0;font-size:13px;color:var(--coral-ink);min-height:1em}
.login-card .btn.primary{width:100%}
'''
s = s.replace('</style>', css + '</style>', 1)

head = '''<!doctype html>
<html lang="es"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="robots" content="noindex,nofollow">
'''
body = s
if not body.lstrip().startswith('<title'):
    head += '<title>TomaNota · Pendientes de hoy</title>\n'
s = head + body.replace('</body></html>', '').rstrip() + '\n</body></html>\n'
s = s.replace('<style>', '</head><body>\n<style>', 1) if '<head>' in s and '</head>' not in s else s

open(dst, 'w', encoding='utf-8').write(s)
js = '\n'.join(re.findall(r'<script>(.*?)</script>', s, re.S))
open(dst + '.js', 'w', encoding='utf-8').write(js)
print('built', dst, len(s))
